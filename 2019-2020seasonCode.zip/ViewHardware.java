package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;
import com.qualcomm.hardware.ams.AMSColorSensor;
import com.qualcomm.hardware.lynx.LynxI2cColorRangeSensor;

 
public class ViewHardware
{
    /* Public OpMode members. */
    //public DcMotor intake = null;
    //public DcMotor intake2 = null;
    //public DcMotor  dumper   = null;
    public DcMotor frm = null;
    public DcMotor flm = null;
    public DcMotor rrm = null;
    public DcMotor rlm = null;
    public DcMotor lift = null;

    /*public DcMotor winch = null;
    public DcMotor l_arm = null;
    public DcMotor r_arm = null;
    public DcMotor sweep = null;
    public Servo color = null;
    public Servo hang = null;
    public Servo fold = null;
    public Servo marker = null;*/
    /* Local OpMode members. */
    HardwareMap hwMap  = null;
    private ElapsedTime period  = new ElapsedTime();

    /* Constructor */
  
    /* Initialize standard Hardware interfaces */
    public void init(HardwareMap ahwMap) {
        // save reference to HW Map
        hwMap = ahwMap;

        // Define and Initialize Motors
        //intake2 = hwMap.get(DcMotor.class, "in2");
        //intake = hwMap.get(DcMotor.class, "in");
        //dumper  = hwMap.get(DcMotor.class, "dump");
        frm = hwMap.get(DcMotor.class, "fr");
        flm = hwMap.get(DcMotor.class, "fl");
        rrm = hwMap.get(DcMotor.class, "rr");
        rlm = hwMap.get(DcMotor.class, "rl");
        

        frm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
       
        flm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rrm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rlm.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
    
        frm.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        flm.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rrm.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rlm.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        
    }

}
